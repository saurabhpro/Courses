
rootProject.name = "Kotlin_for_Java_Developers"

