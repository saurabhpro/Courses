import edu.princeton.cs.algs4.StdOut;
import edu.princeton.cs.algs4.WeightedQuickUnionUF;

/**
 * @author Saurabh Kumar
 */
public class Percolation {

     // Length of the square grid "gridLength * gridLength"
     private final int gridLength;

     // Array representing state of all sites (either it"s open or blocked)
     private final boolean[][] table;
 
     // Number of open sites
     private int openSitesNumber;
 
 
     // Index of the top virtual site (has value 0)
     private final int virtualTopIndex;
 
     // Index of the top virtual site (has value (gridLength * gridLength) + 1)
     private final int virtualBottomIndex;
 
 
     // Weighted quick union-find data structure to calculate percolation
     private final WeightedQuickUnionUF ufForPercolation;
 
     // Weighted quick union-find data structure to calculate fullness (without bottom virtual site)
     private final WeightedQuickUnionUF ufForFullness;
 
     // Create n-by-n grid, with all sites blocked
     public Percolation(int n) {
         if (n < 1) {
             throw new IllegalArgumentException("Grid must have at least one row and column");
         }
 
         this.gridLength = n;
         int gridSize = (n * n) + 2; // with two virtual sites (includes virtual top bottom)
         this.table = new boolean[gridSize][gridSize];
         this.openSitesNumber = 0;
 
         // init virtual sites
         virtualBottomIndex = n * n + 1;
         virtualTopIndex = n * n;
 
         this.ufForPercolation = new WeightedQuickUnionUF(gridSize);
         this.ufForFullness = new WeightedQuickUnionUF(gridSize - 1);
     }
 
     // Open site (row, col) if it is not open already
     public void open(int row, int col) {
         if (isOpen(row, col)) {
             return;
         }
 
         // mark it opened
         table[row - 1][col - 1] = true;
         openSitesNumber++;
 
         final int flatIndex = flattenGridIndex(row, col) - 1;
 
         // connect with top row
         if (row == 1) {
             ufForPercolation.union(virtualTopIndex, flatIndex);
             ufForFullness.union(virtualTopIndex, flatIndex);
         }
 
         // connect with bottom row
         if (row == gridLength) {
             ufForPercolation.union(virtualBottomIndex, flatIndex);
         }
 
         // connect with left neighbor
         if (col > 1 && isOpen(row, col - 1)) {
             final int leftIdx = flattenGridIndex(row, col - 1) - 1;
             ufForPercolation.union(flatIndex, leftIdx);
             ufForFullness.union(flatIndex, leftIdx);
         }
 
         // connect with right neighbor
         if (col < gridLength && isOpen(row, col + 1)) {
             final int rightIdx = flattenGridIndex(row, col + 1) - 1;
             ufForPercolation.union(flatIndex, rightIdx);
             ufForFullness.union(flatIndex, rightIdx);
         }
 
         // connect with top neighbor
         if (row > 1 && isOpen(row - 1, col)) {
             final int topIdx = flattenGridIndex(row - 1, col) - 1;
             ufForPercolation.union(flatIndex, topIdx);
             ufForFullness.union(flatIndex, topIdx);
         }
 
         // connect with bottom neighbor
         if (row < gridLength && isOpen(row + 1, col)) {
             final int bottomIdx = flattenGridIndex(row + 1, col) - 1;
             ufForPercolation.union(flatIndex, bottomIdx);
             ufForFullness.union(flatIndex, bottomIdx);
         }

     }
 
     // If site (row, col) open
     public boolean isOpen(int row, int col) {
         validateBounds(row, col);
         return table[row - 1][col - 1];
     }
 
     // If site (row, col) full
     public boolean isFull(int row, int col) {
         validateBounds(row, col);
         return ufForFullness.find(flattenGridIndex(row, col) - 1) == ufForFullness.find(virtualTopIndex);
     }
 
     // Number of open sites
     public int numberOfOpenSites() {
         return openSitesNumber;
     }
 
     // If the system percolate
     public boolean percolates() {
         return ufForPercolation.find(virtualTopIndex) == ufForPercolation.find(virtualBottomIndex);
     }
 
     // Get site"s index to be represented in array
     private int flattenGridIndex(int row, int col) {
         return ((row - 1) * gridLength) + col;
     }
 
     // Check if row and column values are in range of grid size
     private void validateBounds(int row, int col) {
         if (!isOnGrid(row, col)) {
             throw new IllegalArgumentException("Row/Col index is out of bounds");
         }
     }
     private boolean isOnGrid(int row, int col) {
         int shiftRow = row - 1;
         int shiftCol = col - 1;
 
         return (shiftRow >= 0 && shiftCol >= 0
                 && shiftRow < gridLength && shiftCol < gridLength);
     }

    // Test client (optional)
    public static void main(String[] args) {
        Percolation percolation = new Percolation(2);

        StdOut.println("percolates = " + percolation.percolates());

        StdOut.println("isOpen(1, 2) = " + percolation.isOpen(1, 2));
        StdOut.println("isFull(1, 2) = " + percolation.isFull(1, 2));
        StdOut.println("open(1, 2)");
        percolation.open(1, 2);
        StdOut.println("isOpen(1, 2) = " + percolation.isOpen(1, 2));
        StdOut.println("isFull(1, 2) = " + percolation.isFull(1, 2));
        StdOut.println("numberOfOpenSites() = " + percolation.numberOfOpenSites());
        StdOut.println("percolates() = " + percolation.percolates());

        StdOut.println("isOpen(2, 1) = " + percolation.isOpen(2, 1));
        StdOut.println("isFull(2, 1) = " + percolation.isFull(2, 1));
        StdOut.println("open(2, 1)");
        percolation.open(2, 1);
        StdOut.println("isOpen(2, 1) = " + percolation.isOpen(2, 1));
        StdOut.println("isFull(2, 1) = " + percolation.isFull(2, 1));
        StdOut.println("numberOfOpenSites() = " + percolation.numberOfOpenSites());
        StdOut.println("percolates() = " + percolation.percolates());

        StdOut.println("isOpen(1, 1) = " + percolation.isOpen(1, 1));
        StdOut.println("isFull(1, 1) = " + percolation.isFull(1, 1));
        StdOut.println("open(1, 1)");
        percolation.open(1, 1);
        StdOut.println("isOpen(1, 1) = " + percolation.isOpen(1, 1));
        StdOut.println("isFull(1, 1) = " + percolation.isFull(1, 1));
        StdOut.println("numberOfOpenSites() = " + percolation.numberOfOpenSites());
        StdOut.println("percolates() = " + percolation.percolates());
    }
}